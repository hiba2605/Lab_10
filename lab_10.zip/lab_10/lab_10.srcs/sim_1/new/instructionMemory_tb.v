
`timescale 1ns / 1ps

module instructionMemory_tb;

    reg [31:0] instAddress;
    wire [31:0] instruction;

    reg [31:0] expected [0:38];
    integer i;
    integer errors;

    instructionMemory uut (
        .instAddress(instAddress),
        .instruction(instruction)
    );

    initial begin
        // Expected machine code for all 39 instructions
        expected[0]  = 32'h20000113;
        expected[1]  = 32'h10000297;
        expected[2]  = 32'hffc28293;
        expected[3]  = 32'h0002a303;
        expected[4]  = 32'hfe030ae3;
        expected[5]  = 32'h0002a023;
        expected[6]  = 32'h00030513;
        expected[7]  = 32'h008000ef;
        expected[8]  = 32'hfe5ff06f;
        expected[9]  = 32'hff410113;
        expected[10] = 32'h00112423;
        expected[11] = 32'h00812223;
        expected[12] = 32'h00912023;
        expected[13] = 32'h00050493;
        expected[14] = 32'h10000297;
        expected[15] = 32'hfcc28293;
        expected[16] = 32'h0002a303;
        expected[17] = 32'h02031463;
        expected[18] = 32'h10000297;
        expected[19] = 32'hfc028293;
        expected[20] = 32'h0092a023;
        expected[21] = 32'h02048463;
        expected[22] = 32'h00a00393;
        expected[23] = 32'hfff38393;
        expected[24] = 32'hfe039ee3;
        expected[25] = 32'hfff48493;
        expected[26] = 32'hfd1ff06f;
        expected[27] = 32'h10000297;
        expected[28] = 32'hf9c28293;
        expected[29] = 32'h0002a023;
        expected[30] = 32'h0100006f;
        expected[31] = 32'h10000297;
        expected[32] = 32'hf8c28293;
        expected[33] = 32'h0002a023;
        expected[34] = 32'h00012483;
        expected[35] = 32'h00412403;
        expected[36] = 32'h00812083;
        expected[37] = 32'h00c10113;
        expected[38] = 32'h00008067;

        errors = 0;
        instAddress = 0;
        #10;

        // Test all 39 instructions
        for (i = 0; i < 39; i = i + 1) begin
            instAddress = i * 4;
            #10;

            if (instruction === expected[i]) begin
                $display("PASS: Instruction %0d at address %0d, got %h",
                         i, instAddress, instruction);
            end
            else begin
                $display("FAIL: Instruction %0d at address %0d, expected %h, got %h",
                         i, instAddress, expected[i], instruction);
                errors = errors + 1;
            end
        end

        $display("------------------------------------");

        if (errors == 0)
            $display("ALL 39 INSTRUCTIONS PASSED");
        else
            $display("TEST FAILED: %0d errors out of 39", errors);

        $finish;
    end

endmodule
