module instructionMemory #(
    parameter OPERAND_LENGTH = 31
)(
    input  [OPERAND_LENGTH:0] instAddress,
    output reg [31:0] instruction
);

    // Memory stores 256 instructions, each 32 bits wide.
    reg [31:0] memory [0:255];

    // Load machine-code instructions from a file.
    initial begin
        $readmemh("Instruction_Memory.mem", memory);
    end

    // Read instruction using the program counter.
    always @(*) begin
        if (instAddress[9:2] < 256)
            instruction = memory[instAddress[9:2]];
        else
            instruction = 32'h00000013; // NOP: addi x0, x0, 0
    end

endmodule